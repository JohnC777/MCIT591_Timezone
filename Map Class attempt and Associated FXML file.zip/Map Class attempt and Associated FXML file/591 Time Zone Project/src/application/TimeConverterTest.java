package application;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TimeConverterTest {

	@Test
	void testTimeConverter() {
		fail("Not yet implemented");
	}

	@Test
	void testConvert() {
		fail("Not yet implemented");
	}

	@Test
	void testMain() {
		fail("Not yet implemented");
	}

}
