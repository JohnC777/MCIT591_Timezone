package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

public class MainController {
	
	//instantiate instances to tie back into labels and shapes on maps
	@FXML
	private Label firstPick;
	private Label secondPick;
	private Rectangle location; 
	
	//develop method to select and store location as "zone" variable for use in time converter class
	public void selectLocation(ActionEvent event) {
		firstPick.setText("US_Eastern");
		return;
		
		
	}
	
	public void inputLocation(ActionEvent event) {
		
		
	}
}
