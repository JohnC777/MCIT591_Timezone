package application;

public class TimeCollector {

	//original code deleted following inability to map shapes on Scene Builder
	//generate ids for all rectangles representing each time zone 
	public String LocationSelect (String location) {
		switch(location) {

		case "Pacific_Midway":
			return "Pacific/Midway";

		case "US_Hawaii":
			return "US/Hawaii";


		default:
			break;
		}

		return "Pacific/Midway";

	}
}

